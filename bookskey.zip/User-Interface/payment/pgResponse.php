<?php
header("Pragma: no-cache");
header("Cache-Control: no-cache");
header("Expires: 0");

// Include the required Paytm libraries
require_once("./lib/config_paytm.php");
require_once("./lib/encdec_paytm.php");

// Initialize variables
$paytmChecksum = "";
$paramList = array();
$isValidChecksum = "FALSE";

// Get POST data from Paytm
$paramList = $_POST;
$paytmChecksum = isset($_POST["CHECKSUMHASH"]) ? $_POST["CHECKSUMHASH"] : ""; // Sent by Paytm

// Verify the checksum
$isValidChecksum = verifychecksum_e($paramList, PAYTM_MERCHANT_KEY, $paytmChecksum); // will return TRUE or FALSE string.
?>

<!DOCTYPE html>
<html>
<head>
    <title>Payment Response</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../../css/styleInvoice.css">
</head>
<body>
<header>
    <h1>Shopping Details:</h1>
    <img src="../../pic/logo1.png" width="200px" height="70px">
</header>

<div class="main-container shadow bg-white rounded">

<?php if ($isValidChecksum == "TRUE") { ?>

    <div class="main-header">
        <h3><b>Enrollment Details:</b></h3>
        <button type="button" class="btn btn-primary" onclick="myFunction()">Print Acknowledgement</button>
    </div>
    
    <div class="transcation-status" style="color: <?= ($_POST["STATUS"] == "TXN_SUCCESS") ? 'green' : 'red' ?>">
        <h5><b>Transaction status is <?= ($_POST["STATUS"] == "TXN_SUCCESS") ? 'success' : 'failure' ?></b></h5>
    </div>

    <div class="billing-content">
        <div>
            <h4>Shipping Details:</h4>
            <?php
            try {
                $db = new PDO('mysql:host=localhost;dbname=bookstore;charset=utf8', 'root', '');
            } catch (Exception $e) {
                echo "Error has occurred: " . $e->getMessage();
            }

            $ORDERID = $_POST['ORDERID'];
            $stmt = $db->prepare("SELECT * FROM transcationbook WHERE OrderId = :orderId");
            $stmt->bindParam(':orderId', $ORDERID);
            $stmt->execute();

            if ($row = $stmt->fetch()) {
                echo $row['name'] . "<br>Address: " . $row['Address'] . "<br>Contact Details: " . $row['contactDetail'] . "<br>Payment: " . $row['price'];
                $Cid = $row['Cid'];
            }
            ?>
        </div>

        <div>
            <h4>Payment Info:</h4>
            <?php
            if (isset($_POST) && count($_POST) > 0) {
                echo "Order ID: " . $_POST['ORDERID'] . "<br/>";
                echo "PAYTM_MERCHANT_MID: " . $_POST['MID'] . "<br/>";
                echo "Transaction ID: " . $_POST["TXNID"] . "<br/>";
                echo "Transaction Status: " . $_POST["STATUS"] . "<br/>";
                echo "Transaction Amount: " . $_POST["TXNAMOUNT"] . "<br/>";
                echo "Currency: " . $_POST["CURRENCY"] . "<br/>";
                echo "Transaction Date: " . $_POST["TXNDATE"] . "<br/>";
                echo "Payment Mode: " . $_POST["PAYMENTMODE"] . "<br/>";
                echo "Bank Name: " . $_POST["BANKNAME"] . "<br/>";
                echo "Bank Transaction ID: " . $_POST['BANKTXNID'] . "<br/>";

                $details = "Order ID: " . $ORDERID . "<br>PAYTM_MERCHANT_MID: " . $_POST['MID'] . "<br>Transaction ID: " . $_POST["TXNID"] . "<br>Transaction Status: " . $_POST["STATUS"] .
                    "<br>Transaction Amount: " . $_POST["TXNAMOUNT"] . "<br>Currency: " . $_POST["CURRENCY"] . "<br>Transaction Date: " . $_POST["TXNDATE"] . "<br>Payment Mode: " . $_POST['PAYMENTMODE'] .
                    "<br>Bank Name: " . $_POST['BANKNAME'] . "<br>Bank Transaction ID: " . $_POST['BANKTXNID'];

                $exp = date("Y-m-d", strtotime("+1 week"));
                $statusTXN = ($_POST["STATUS"] == "TXN_SUCCESS") ? 'Order Confirmed' : 'Order Cancelled';

                $stmt = $db->prepare("UPDATE transcationbook SET PaymentInfo = :details, txnStatus = :status, exceptDate = :exp, OrderStatus = :orderStatus, DeliveryDate = NOW() WHERE OrderId = :orderId");
                $stmt->bindParam(':details', $details);
                $stmt->bindParam(':status', $_POST["STATUS"]);
                $stmt->bindParam(':exp', $exp);
                $stmt->bindParam(':orderStatus', $statusTXN);
                $stmt->bindParam(':orderId', $ORDERID);
                $stmt->execute();
            }
            ?>
        </div>
    </div> <!-- Billing content -->

    <?php if ($_POST["STATUS"] == "TXN_SUCCESS") { ?>
        <div class="order-summary">
            <h2><b>Order Summary:</b></h2>
            <?php
            $stmt = $db->prepare("SELECT * FROM cart WHERE cid = :cid");
            $stmt->bindParam(':cid', $Cid);
            $stmt->execute();

            while ($row = $stmt->fetch()) {
                $pid = $row['Pid'];
                $quantity = $row['Quantity'];
                $st = $db->prepare("INSERT INTO orderlist (OrderID, Cid, Pid, Quantity) VALUES (:orderId, :cid, :pid, :quantity)");
                $st->bindParam(':orderId', $ORDERID);
                $st->bindParam(':cid', $Cid);
                $st->bindParam(':pid', $pid);
                $st->bindParam(':quantity', $quantity);
                $st->execute();
            }

            $stmt = $db->prepare("DELETE FROM cart WHERE Cid = :cid");
            $stmt->bindParam(':cid', $Cid);
            $stmt->execute();
            ?>

            <table class="table table-hover ">
                <tr>
                    <td class="col-sm-8 col-md-6"><b>Product</b></td>
                    <td><b>Seats</b></td>
                    <td><b>Price</b></td>
                    <td colspan="2"><b>Total</b></td>
                </tr>
                <?php
                $stmt = $db->prepare("SELECT product.title AS Title, product.price AS Price, product.description AS Description, product.image AS Image, product.price * orderlist.Quantity AS TotalAmount, orderlist.Quantity AS Quantity FROM orderlist LEFT JOIN product ON orderlist.Pid = product.id WHERE orderlist.OrderID = :orderId");
                $stmt->bindParam(':orderId', $ORDERID);
                $stmt->execute();

                while ($row = $stmt->fetch()) { ?>
                    <tr>
                        <td class="col-sm-8 col-md-6">
                            <div class="media">
                                <a class="thumbnail pull-left" href="#"> <img src="../../pic/book/<?php echo $row['Image']; ?>" alt="" style="width:72px; height: 72px;"></a>
                                <div style="padding-left: 10px;" class="media-body">
                                    <h4 class="media-heading"><a href="#"><?php echo $row['Title']; ?></a></h4>
                                    <p><?php echo substr($row['Description'], 0, 60) . '...'; ?></p>
                                </div>
                            </div>
                        </td>
                        <td><?php echo $row['Quantity']; ?></td>
                        <td><?php echo $row['Price']; ?></td>
                        <td colspan="2"><?php echo $row['TotalAmount']; ?></td>
                    </tr>
                <?php } ?>
            </table>
        </div>
    <?php } ?>

<?php } else { ?>
    <div class="transcation-status" style="color:red">
        <h5><b>Checksum mismatch! Please try again.</b></h5>
    </div>
<?php } ?>

</div> <!-- Main container -->
</body>
</html>
